<script setup>
    import { ref } from 'vue';

    const count = ref(0);
</script>

<template>
    <div class="container">
        <h1>Привіт, світ! Це Vue.js 🟢</h1>
        <p>Виконав(ла): <strong>Куліковська Альона, група КН-31</strong></p>
        <button class="btn" @click="count++">
            Кліків: {{ count }}
        </button>
    </div>
</template>

<style scoped>
    .container {
        text-align: center;
        font-family: sans-serif;
        margin-top: 50px;
    }

    .btn {
        padding: 10px 20px;
        font-size: 16px;
        cursor: pointer;
    }
</style>
